#include "led.h"


// Class Implementation //



// Constructor //

Counter::Counter(int pin1, int pin2, int pin3, int pin4, int pin5, int pin6, int pin7, int pin8){
  _pins[0] = pin1;
  _pins[1] = pin2;
  _pins[2] = pin3;
  _pins[3] = pin4;
  _pins[4] = pin5;
  _pins[5] = pin6;
  _pins[6] = pin7;
  _pins[7] = pin8;
}

// Method 1 //

void Counter::begin(){
  for (int i = 0; i<8; i++){
    pinMode(_pins[i], OUTPUT);
  }
}


// Method 2 //

void Counter::upCount(){
  for(int num = 0; num<256; num++){
    Serial.println(num);
    for(int i = 0; i <8; i++){
      boolean b = bitRead(num, i);
      Serial.print(b);
      Serial.print(" ");
      digitalWrite(_pins[i], !(b));
      
    }
    Serial.println("");
    delay(600);
  }
}


// Method 3 //

void Counter::downCount() {
  for(int num = 255; num>=0; num--){
    for(int i = 0; i <8; i++){
      int b = bitRead(num, i);
      Serial.print(b);
      Serial.print(" ");
      digitalWrite(_pins[i], !(b));
      
    }
    Serial.println("");
    delay(600);
  }
}

// Method 4 //

void Counter::shiftRight(){
  while(1){
    for (int i = 0; i<8; i++){
      if(i == 0){
        digitalWrite(_pins[i], LOW);
        delay(50);
      }
      else if(i>0){
        digitalWrite(_pins[i-1], HIGH);
        delay(50);
        digitalWrite(_pins[i], LOW);
        delay(50);
        digitalWrite(_pins[i], HIGH);
        delay(50);
        
      }
    }
  }
}

// Method 5 //

void Counter::shiftLeft(){
  while(1){
    for (int i = 7; i>=0; i--){
      if(i == 7){
        digitalWrite(_pins[i], LOW);
        delay(50);
      }
      else if(i<7){
        digitalWrite(_pins[i+1], HIGH);
        delay(50);
        digitalWrite(_pins[i], LOW);
        delay(50);
        digitalWrite(_pins[i], HIGH);
        delay(50);
      }
    }
  }
}

// Method 6 //

void Counter::allOff() {
  for(int i = 0; i<8; i++){
    digitalWrite(_pins[i], HIGH);
  } 
}