#include <Arduino.h>

// Class Header //

class Counter {
  private:
    int _pins[8];

  public:
    Counter(int, int, int, int, int, int, int, int);
    void begin();
    void upCount();
    void downCount();
    void shiftLeft();
    void shiftRight();
    void allOff();
};